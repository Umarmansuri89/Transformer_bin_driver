import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intro_views_flutter/intro_views_flutter.dart';
import 'package:shyam_trust_flutter/app/routes/app_pages.dart';
import 'package:shyam_trust_flutter/app/utils/image_helper.dart';
import '../controllers/welcome_controller.dart';

class WelcomeView extends GetView<WelcomeController> {
  WelcomeController controller = WelcomeController();

  final pages = [
    PageViewModel(
      pageBackground: Stack(
        children: [
          Container(
            height: double.infinity,
            width: double.infinity,
            child: Image.asset(WELCOME_14, fit: BoxFit.cover),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: Text(
                      '''\n\n\n\n\n\n\n Select One of Our Hot Packages \n To Choose The Kind of Show \n You Desire''',
                      overflow: TextOverflow.visible,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        height: 1.4166666666666667,
                        fontSize: 15.0,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w500,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 50, bottom: 10),
                    child: GestureDetector(
                      onTap: () {},
                      child: Stack(
                        children: [
                          Container(
                            height: 50,
                            child: SvgPicture.asset(BUTTON_IMAGE),
                          ),
                          Center(
                              child: Padding(
                            padding: const EdgeInsets.only(top: 12.0),
                            child: Text(
                              "Next",
                              style: TextStyle(
                                height: 1.4166666666666667,
                                fontSize: 15.0,
                                fontFamily: 'Lato',
                                fontWeight: FontWeight.w600,
                                color: Color.fromARGB(255, 255, 255, 255),
                              ),
                            ),
                          )),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: Text(
                      "Skip",
                      style: TextStyle(
                        height: 1.4166666666666667,
                        fontSize: 13.0,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
      iconColor: Colors.pink,

      /*bubble: SvgPicture.asset(
        RECT_IMAGE,
      ),*/
      bubbleBackgroundColor: Colors.pink,
    ),
    PageViewModel(
      pageBackground: Stack(
        children: [
          Container(
            height: double.infinity,
            width: double.infinity,
            child: Image.asset(WELCOME_2, fit: BoxFit.cover),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: Text(
                      '''\n\n\n\n\n\n\n  Select Your City Location & Choose \n Your Eye Kandy. Select From Our \n Choice of Girls In That Location''',
                      overflow: TextOverflow.visible,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        height: 1.4166666666666667,
                        fontSize: 15.0,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w500,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 50, bottom: 10),
                    child: GestureDetector(
                      onTap: () {},
                      child: Stack(
                        children: [
                          Container(
                            height: 50,
                            child: SvgPicture.asset(BUTTON_IMAGE),
                          ),
                          Center(
                              child: Padding(
                            padding: const EdgeInsets.only(top: 12.0),
                            child: Text(
                              "Next",
                              style: TextStyle(
                                height: 1.4166666666666667,
                                fontSize: 15.0,
                                fontFamily: 'Lato',
                                fontWeight: FontWeight.w600,
                                color: Color.fromARGB(255, 255, 255, 255),
                              ),
                            ),
                          )),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: Text(
                      "Skip",
                      style: TextStyle(
                        height: 1.4166666666666667,
                        fontSize: 13.0,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
      /* bubble: SvgPicture.asset(
        RECT_IMAGE,
      ),*/
      bubbleBackgroundColor: Colors.pink,
    ),
    PageViewModel(
      pageBackground: Stack(
        children: [
          Container(
            height: double.infinity,
            width: double.infinity,
            child: Image.asset(welcome_4x, fit: BoxFit.cover),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: Text(
                      '''\n\n\n\n\n Enter Your Party Details. Choose \n Party Type, Costume Choices & Pay \nFor Your Order. Get Ready For\n A Sexy Sizzling Hot Show! ''',
                      overflow: TextOverflow.visible,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        height: 1.4166666666666667,
                        fontSize: 15.0,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w500,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 50, bottom: 10),
                    child: GestureDetector(
                      onTap: () => onSubmit(),
                      child: Stack(
                        children: [
                          Container(
                            height: 50,
                            child: SvgPicture.asset(BUTTON_IMAGE),
                          ),
                          Center(
                              child: Padding(
                            padding: const EdgeInsets.only(top: 12.0),
                            child: Text(
                              "Next",
                              style: TextStyle(
                                height: 1.4166666666666667,
                                fontSize: 15.0,
                                fontFamily: 'Lato',
                                fontWeight: FontWeight.w600,
                                color: Color.fromARGB(255, 255, 255, 255),
                              ),
                            ),
                          )),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    child: Text(
                      "Skip",
                      style: TextStyle(
                        height: 1.4166666666666667,
                        fontSize: 13.0,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w600,
                        color: Color.fromARGB(255, 255, 255, 255),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
      // iconImageAssetPath: 'assets/air-hostess.png',
      /*bubble: SvgPicture.asset(
        RECT_IMAGE,
      ),*/

      bubbleBackgroundColor: Colors.pink,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    this.controller = controller;
    return Scaffold(
      body: Builder(
        builder: (context) => IntroViewsFlutter(
          pages,
          backText: Text(''),
          showNextButton: false,
          showBackButton: false,
          showSkipButton: false,
          doneButtonPersist: false,
          skipText: Text(''),
          doneText: Text(''),
          fullTransition: 100,
          onTapDoneButton: () {
            // controller.onSubmit();
            // Use Navigator.pushReplacement if you want to dispose the latest route
            // so the user will not be able to slide back to the Intro Views.
          },
        ),
      ),
    );
  }
}

onSubmit() {
  Get.toNamed(Routes.LOGIN);
}
